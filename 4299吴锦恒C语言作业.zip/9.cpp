#include <stdio.h>

int main(){
    int a[16] = {0};
    int x;
    int low, high, mid;
    int cnt = 0;
    printf("please enter 15 numbers from high to low\n");
    for(int i = 1; i < 16; i++){
        scanf("%d", &a[i]); 
    }
    printf("which word do you want to check\n");
    scanf("%d", &x);

    low = 1;
    high = 15;

    while(low <= high){
        mid = (low + high) / 2;
        if(x > a[mid]){
            low = mid + 1;
        }
        else if(x == a[mid]){
            cnt = mid;
            break;
        }
        else{
            high = mid - 1;
        }
    }

    if(cnt == 0){
        printf("404 not found");
    }
    else{
        printf("The location is %d", cnt);
    }

    getchar();
    getchar();
    return 0;
}
