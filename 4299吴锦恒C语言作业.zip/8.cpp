#include <stdio.h>
# define N 3
int main(){
int a[N][N];
printf("please enter 9 numbers :\n");
for(int i=0;i<N;i++){
    for(int j=0;j<N;j++){
        scanf("%d",&a[i][j]);
    }
}
int x=0;
for(int i=0;i<N;i++){
    x=0;
    int maxindex=0;
    int max=a[i][0];
    for(int j=0;j<N;j++){
        if(a[i][j]>max){
            max=a[i][j];
            maxindex=j;
        }
        for(int k=0;k<N;k++){
            if(a[k][maxindex]<max){
                x=1;
            }
        }
    }
    if(x==0){
        printf("the anwser is %d",a[i][maxindex]);
        break;
    }
}
if(x==1){
    printf("no saddle");
}
    getchar();
    getchar();
    return 0;
}
