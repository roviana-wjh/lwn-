#include <stdio.h>
# define N 6
int main(){
printf("please enter N number");
int a[N];
for(int i=0;i<6;i++){
    scanf("%d",&a[i]);
}
printf("Now the array is :  \n");
for(int i=0;i<N;i++){
    for(int j=0;j<N-i;j++){
        if(a[j]>a[j+1]){
            int temp=a[j];
            a[j]=a[j+1];
            a[j+1]=temp;
        }
    }
}
for(int i=0;i<N;i++){
    printf("%d ",a[i]);
}
    getchar();
    getchar();
    return 0;
}
