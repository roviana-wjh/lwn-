#include <stdio.h>

int main() {
    int a[10];
    for (int i = 0; i < 10; i++) {
        printf("please enter numbers\n");
        scanf("%d", &a[i]);
    }

    int index;
    for (int i = 0; i < 9; i++) {  
        index = i;
        for (int j = i + 1; j < 10; j++) {
            if (a[index] > a[j]) {
                index = j;
            }
        }
        if (index!= i) {  
            int temp = a[i];
            a[i] = a[index];
            a[index] = temp;
        }
    }

    printf("the answer is\n");
    for (int i = 0; i < 10; i++) {
        printf("%d ", a[i]);
    }

    getchar();
    getchar();
    return 0;
}
